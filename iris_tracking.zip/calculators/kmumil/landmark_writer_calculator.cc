#include <fstream>
#include <cstdlib>
#include <cmath>

#include "gnuplot.h"
#include "mediapipe/framework/api2/node.h"
#include "mediapipe/framework/calculator_framework.h"
#include "mediapipe/framework/port/ret_check.h"
#include "mediapipe/framework/formats/landmark.pb.h"


static float ex_x = 0.0;
static float ex_y = 0.0;


namespace mediapipe {

namespace api2 {
class LandmarkWriterCalculator : public Node {
 public:
  static constexpr Input<mediapipe::NormalizedLandmarkList> kInLandmarks{"IRIS_LANDMARKS_LEFT"};
  static constexpr Output<int>::Optional kOutUnused{"INT"};
  MEDIAPIPE_NODE_INTERFACE(LandmarkWriterCalculator, kInLandmarks, kOutUnused);
  
  static mediapipe::Status UpdateContract(CalculatorContract* cc) {
    
    return mediapipe::OkStatus();
  }

  mediapipe::Status Open(CalculatorContext* cc) final {
    out_path = getenv("HOME");
    out_path += "/landmarks.csv";
    
    file.open(out_path);
    RET_CHECK(file);
    file <<"changed_rate" << std::endl;
    
    return mediapipe::OkStatus();
  }
  
  mediapipe::Status Process(CalculatorContext* cc) final {
    const mediapipe::NormalizedLandmarkList& landmarks = *kInLandmarks(cc);

    float change_rate = 0;

    const mediapipe::NormalizedLandmark& landmark = landmarks.landmark(0);

    change_rate = (pow(ex_x-landmark.x(),2) + pow(ex_y-landmark.y(),2))*1000;
    ex_x = landmark.x();
    ex_y = landmark.y();
    file << change_rate;
    file << std::endl;
    
    std::string home = getenv("HOME");
    GnuplotPipe gp;
    gp.sendLine("set datafile separator ','");
    gp.sendLine("set terminal png");
    gp.sendLine("set output '"+home+"/plot.png'");
    gp.sendLine("set xlabel 'frames'");
    gp.sendLine("set yrange [0:0.5]");
    gp.sendLine("set ytics 0.05");
    gp.sendLine("plot '"+out_path+"' using 'changed_rate' with linespoint ls 1 pt 5");

    return mediapipe::OkStatus();
  }
  
 private:
  std::ofstream file;
  std::string out_path;
};

MEDIAPIPE_REGISTER_NODE(LandmarkWriterCalculator);
}

}
