#include <fstream>
#include <cstdlib>
#include <cmath>

#include "gnuplot.h"
#include "mediapipe/framework/api2/node.h"
#include "mediapipe/framework/calculator_framework.h"
#include "mediapipe/framework/port/ret_check.h"
#include "mediapipe/framework/formats/landmark.pb.h"
#include "mediapipe/framework/formats/rect.pb.h"
#include "mediapipe/framework/formats/detection.pb.h"

namespace mediapipe {

namespace api2 {
class FaceInfoWritePlotCalculator : public Node {
 public:
 
  // input value
  static constexpr Input<std::vector<mediapipe::NormalizedLandmarkList, std::allocator<mediapipe::NormalizedLandmarkList>>> kInLandmarks1{"LANDMARKS"}; //kInLandmarks3
  static constexpr Input<std::vector<mediapipe::NormalizedRect, std::allocator<mediapipe::NormalizedRect>>> kInLandmarks2{"NORM_RECTS"};
  // static constexpr Input<std::vector<mediapipe::Detection, std::allocator<mediapipe::Detection> >> kInLandmarks3{"DETECTIONS"};
  static constexpr Output<int>::Optional kOutUnused{"INT"};
  
  MEDIAPIPE_NODE_INTERFACE(FaceInfoWritePlotCalculator, kInLandmarks1, kInLandmarks2, kOutUnused);
  
  static mediapipe::Status UpdateContract(CalculatorContract* cc) {

    return mediapipe::OkStatus();
  }

  mediapipe::Status Open(CalculatorContext* cc) final {
    out_path = getenv("HOME");
    out_path += "/landmarks.csv";
    file.open(out_path);

    out_path = getenv("HOME");
    out_path += "/landmarks2.csv";
    file2.open(out_path);


    RET_CHECK(file);
    file <<"x, y" << std::endl;
    
    return mediapipe::OkStatus();
  }
  
  mediapipe::Status Process(CalculatorContext* cc) final {
    // std::cout<<"cc: " << typeid(cc).name() << std::endl;
    const std::vector<mediapipe::NormalizedLandmarkList, std::allocator<mediapipe::NormalizedLandmarkList>>& LANDMARKS = *kInLandmarks1(cc);
    const std::vector<mediapipe::NormalizedRect, std::allocator<mediapipe::NormalizedRect>>& NORM_RECTS = *kInLandmarks2(cc);
    // const std::vector<mediapipe::Detection, std::allocator<mediapipe::Detection>> DETECTIONS = *kInLandmarks3(cc);
    // std::cout<<"=========================================START=========================================\n";
    // std::cout<<"LAND MARKS"<<std::endl;
    // std::cout<<LANDMARKS[0].landmark_size()<<std::endl;
    // std::cout<<LANDMARKS[1].landmark_size()<<std::endl;

    if (LANDMARKS[0].landmark_size() == 468){

      for(int i = 0; i < 468; ++i){
        const mediapipe::NormalizedLandmark& lm = LANDMARKS[0].landmark(i);
        file<<lm.x()<<","<< lm.y()<<std::endl;
      }
    }
    else{
      for(int i = 0; i < 468; ++i){
        file<<0.0<<","<< 0.0<<std::endl;
      }


    }
    // int landmark_size = LANDMARKS[1].landmark_size();
    // if(landmark_size == 7){
    //   std::cout << landmark_size<<std::endl;
    //   for(int i = 0; i < 7; ++i){
    //     file<<LANDMARKS[1].landmark(i).x()<<","<< LANDMARKS[1].landmark(i).y()<<std::endl;
    //   }
    // }

    // std::cout<<"NORM_RECTS"<<std::endl;
    // std::cout<<"rect_id: " << NORM_RECTS[0].rect_id()<<std::endl;
    // std::cout<<"height: " << NORM_RECTS[0].height()<<std::endl;
    // std::cout<<"width : " <<NORM_RECTS[0].width()<<std::endl;
    // std::cout<<"x_center : " << NORM_RECTS[0].x_center()<<std::endl;
    // std::cout<<"y_center : " << NORM_RECTS[0].y_center()<<std::endl;
    // std::cout<<std::endl;    
    // std::cout<<NORM_RECTS[1].rect_id();
    // std::cout<<NORM_RECTS[1].height();
    // std::cout<<NORM_RECTS[1].width();
    // std::cout<<NORM_RECTS[1].x_center();
    // std::cout<<NORM_RECTS[1].y_center();
    // std::cout<<std::endl;    
    // std::cout<<"DETECTIONS"<<std::endl;
    // std::cout<<"label_size : " << DETECTIONS[0].label_size()<<std::endl;
    // std::cout<<"label :" <<DETECTIONS[0].label().data()<<std::endl;
    // // std::cout<<DETECTIONS[0].label_id()<<std::endl;
    // std::cout<<"label_id_size :" <<DETECTIONS[0].label_id_size()<<std::endl;
    // // std::cout<<DETECTIONS[0].location_data()<<std::endl;
    // std::cout<<"display_name_size :" <<DETECTIONS[0].display_name_size()<<std::endl;
    // std::cout<<"display_name :" <<DETECTIONS[0].display_name().data()<<std::endl;
    // std::cout<<"has_detection_id :" <<DETECTIONS[0].has_detection_id()<<std::endl;
    




    // for(int i = 0; i < LANDMARKS[0].landmark_size(); ++i){
    //   const mediapipe::NormalizedLandmark& lm = LANDMARKS[0].landmark(i);
    //   std::cout<<lm.x()<<std::endl;
    //   std::cout<<lm.y()<<std::endl;
    //   std::cout<<lm.visibility()<<std::endl;
    //   std::cout<<"============================================================================"<<std::endl;
    // }
    // std::cout<<"+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<std::endl;
    
    // for(int i = 0; i < LANDMARKS[1].landmark_size(); ++i){
    //   const mediapipe::NormalizedLandmark& lm = LANDMARKS[0].landmark(i);
    //   std::cout<<lm.x()<<std::endl;
    //   std::cout<<lm.y()<<std::endl;
    //   std::cout<<lm.visibility()<<std::endl;
    //   std::cout<<"============================================================================"<<std::endl;
    // }

    // for(int i = 0; i< )

    // float change_rate = 0;
    // float center_coord_x= 0.0;
    // float center_coord_y= 0.0;
    // float difference = 0.0;

    // const mediapipe::NormalizedLandmark& center = LANDMARKS.landmark(0);

    // for (int i = 0; i < LANDMARKS[0].landmark_size(); ++i) {
    //   const mediapipe::NormalizedLandmark& landmark = LANDMARKS[0].landmark(i);
    //   // center_coord_x += landmark.x();
    //   // center_coord_y += landmark.y();
    //   //file << i << ':' << landmark.x() << ',' << landmark.y() << ',';
    //   //file << std::endl;
    // }
    
    // center_coord_x /= 71;
    // center_coord_y /= 71;      
    // change_rate = (pow(center.x()-center_coord_x,2) + pow(center.y()-center_coord_y,2))*1000;
     
    // file << change_rate;        
    // file << std::endl;
    
    // std::string home = getenv("HOME");
    // GnuplotPipe gp;
    // gp.sendLine("set datafile separator ','");
    // gp.sendLine("set terminal png");
    // gp.sendLine("set output '"+home+"/plot.png'");
    // gp.sendLine("set xlabel 'frames'");
    // gp.sendLine("set yrange [0:0.3]");
    // gp.sendLine("set ytics 0.01");
    // gp.sendLine("plot '"+out_path+"' using 'changed_rate' with linespoint ls 1 pt 5");

    return mediapipe::OkStatus();
  }
  
 private:
  std::ofstream file;
  std::string file_path;
  std::ofstream file2;
  std::string file2_path;
        
  std::string out_path;
};

MEDIAPIPE_REGISTER_NODE(FaceInfoWritePlotCalculator);
}

}
