#include <fstream>
#include <cstdlib>
#include "gnuplot.h"

#include "absl/memory/memory.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_join.h"
#include "mediapipe/framework/calculator_framework.h"
#include "mediapipe/framework/formats/detection.pb.h"
#include "mediapipe/framework/formats/location_data.pb.h"
#include "mediapipe/framework/port/ret_check.h"

using namespace std;

namespace mediapipe {

namespace{
constexpr char kDetectionsTag[] = "DETECTIONS";
}

class DetectionInfoWritePlotCalculator : public CalculatorBase {
    public:
        DetectionInfoWritePlotCalculator() {}
        ~DetectionInfoWritePlotCalculator() override {}
        DetectionInfoWritePlotCalculator(const DetectionInfoWritePlotCalculator&) = 
            delete;

        DetectionInfoWritePlotCalculator& operator=(
            const DetectionInfoWritePlotCalculator&) = delete;
        
        static mediapipe::Status GetContract(CalculatorContract* cc);
        
        mediapipe::Status Open(CalculatorContext* cc) override;
        
        mediapipe::Status Process(CalculatorContext* cc) override;
        
    private:
        std::ofstream file;
        // std::vector<std::vector<int>(2)>() history;
        std::string file_path;
};
REGISTER_CALCULATOR(DetectionInfoWritePlotCalculator);      



mediapipe::Status DetectionInfoWritePlotCalculator::GetContract(CalculatorContract* cc) {
    RET_CHECK(cc->Inputs().HasTag(kDetectionsTag)) 
    << "None of the input streams are provided.";
    cc->Inputs().Tag(kDetectionsTag).Set<std::vector<Detection>>();
    return mediapipe::OkStatus();
}

mediapipe::Status DetectionInfoWritePlotCalculator::Open(CalculatorContext* cc) {
    file_path = "/mediapipe/output/od"; // getenv("HOME")
    file_path += "/detections.csv";

    file.open(file_path);
    RET_CHECK(file);
    file<<"person,object"<<std::endl;
    
    return mediapipe::OkStatus();
}

mediapipe::Status DetectionInfoWritePlotCalculator::Process(CalculatorContext* cc) {
    const bool has_detection_from_vector =
      cc->Inputs().HasTag(kDetectionsTag) &&
      !cc->Inputs().Tag(kDetectionsTag).Get<std::vector<Detection>>().empty();
      
    int person = 0;
    int object = 0;
    if (has_detection_from_vector){
        for (const auto& detection : 
                cc->Inputs().Tag(kDetectionsTag).Get<std::vector<Detection>>()) {
            
            const auto num_labels = std::max(detection.label_size(), detection.label_id_size());
            for (int i = 0; i < num_labels; ++i) {
                std::string label_str = detection.label().empty()
                                            ? absl::StrCat(detection.label_id(i))
                                            : detection.label(i);
                if(label_str.compare("person")==0){
                    person++;
                }    
                else{
                    object++;
                }
                break;
            }
        }
    }
    // std::vector<int> now = {person, object};
    // history.add(now);        
    file << person<<","<<object <<std::endl;    

    std::string plot_path = "/mediapipe/output/od";
    GnuplotPipe gp;
    gp.sendLine("set datafile separator ','");
    gp.sendLine("set terminal png");
    gp.sendLine("set output '"+plot_path+"/od_plot.png'");
    gp.sendLine("set xlabel 'frames'");
    gp.sendLine("set yrange [0:4]");
    gp.sendLine("set ytics 1");
    gp.sendLine("plot '"+file_path+"' using 'person' with linespoint ls 1 pt 5,'' using 'object' with linespoint ls 2 pt 7");

    return mediapipe::OkStatus();
}
} //namespace mediapipe
  
